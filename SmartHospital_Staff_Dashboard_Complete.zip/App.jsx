import { useEffect, useState } from "react";
import {
  Activity,
  ArrowLeft,
  Bed,
  Calendar,
  CheckCircle2,
  Clock3,
  Filter,
  GitCompare,
  Hospital,
  MapPin,
  Navigation,
  Phone,
  Search,
  ShieldCheck,
  Star,
  Stethoscope,
  User,
  Users,
  X,
} from "lucide-react";

import PatientDashboard from "./pages/PatientDashboard";
import HospitalStaffDashboard from "./pages/HospitalStaffDashboard";

/* =========================================================
   HOSPITAL DATA
   ========================================================= */

const hospitals = [
  {
    id: 1,
    name: "CityCare Multispeciality Hospital",
    location: "Indore, Madhya Pradesh",
    address: "AB Road, Vijay Nagar, Indore, Madhya Pradesh",
    coordinates: { lat: 22.7533, lng: 75.8937 },
    phone: "+91 98765 43210",
    distance: "2.4 km",
    rating: 4.7,
    reviews: 328,

    specialties: [
      "Cardiology",
      "Neurology",
      "Orthopedics",
    ],

    services: [
      "Emergency",
      "Diagnostics",
      "ICU",
      "Pharmacy",
    ],

    wait: "18 min",
    queue: 7,
    beds: 12,
    emergency: "Available",
    updated: "18 seconds ago",
    status: "Open",
    hours: "Open 24 hours",

    reviewInsights: [
      "Doctors are highly rated",
      "Short waiting times",
      "Good emergency response",
    ],

    doctors: [
      {
        name: "Dr. Rajiv Sharma",
        specialty: "Cardiology",
        qualification: "MD, DM Cardiology",
        experience: "14 years",
        availability: "Available today",
        verified: true,
      },
      {
        name: "Dr. Priya Mehta",
        specialty: "Neurology",
        qualification: "MBBS, MD, DM Neurology",
        experience: "11 years",
        availability: "Available today",
        verified: true,
      },
      {
        name: "Dr. Amit Verma",
        specialty: "Orthopedics",
        qualification: "MBBS, MS Orthopedics",
        experience: "9 years",
        availability: "Available tomorrow",
        verified: true,
      },
    ],
  },

  {
    id: 2,
    name: "LifeLine Medical Centre",
    location: "Indore, Madhya Pradesh",
    address: "Scheme No. 54, Indore, Madhya Pradesh",
    coordinates: { lat: 22.7525, lng: 75.8950 },
    phone: "+91 98765 12345",
    distance: "4.1 km",
    rating: 4.5,
    reviews: 241,

    specialties: [
      "Cardiology",
      "General Medicine",
      "Dermatology",
    ],

    services: [
      "Emergency",
      "Diagnostics",
      "Pharmacy",
    ],

    wait: "25 min",
    queue: 11,
    beds: 8,
    emergency: "Available",
    updated: "32 seconds ago",
    status: "Open",
    hours: "Open 24 hours",

    reviewInsights: [
      "Good doctor availability",
      "Clean facilities",
      "Helpful staff",
    ],

    doctors: [
      {
        name: "Dr. Neha Kapoor",
        specialty: "Cardiology",
        qualification: "MBBS, MD Cardiology",
        experience: "12 years",
        availability: "Available today",
        verified: true,
      },
      {
        name: "Dr. Rahul Jain",
        specialty: "General Medicine",
        qualification: "MBBS, MD Medicine",
        experience: "10 years",
        availability: "Available today",
        verified: true,
      },
    ],
  },

  {
    id: 3,
    name: "MedPlus Advanced Hospital",
    location: "Indore, Madhya Pradesh",
    address: "Ring Road, Indore, Madhya Pradesh",
    coordinates: { lat: 22.7196, lng: 75.8577 },
    phone: "+91 99887 66554",
    distance: "6.7 km",
    rating: 4.3,
    reviews: 187,

    specialties: [
      "Neurology",
      "Orthopedics",
      "Pediatrics",
    ],

    services: [
      "ICU",
      "Diagnostics",
      "Pharmacy",
    ],

    wait: "12 min",
    queue: 4,
    beds: 5,
    emergency: "Limited",
    updated: "1 minute ago",
    status: "Open",
    hours: "Open 24 hours",

    reviewInsights: [
      "Low waiting time",
      "Good specialist availability",
      "Modern diagnostics",
    ],

    doctors: [
      {
        name: "Dr. Ankit Patel",
        specialty: "Neurology",
        qualification: "MBBS, MD, DM Neurology",
        experience: "13 years",
        availability: "Available today",
        verified: true,
      },
      {
        name: "Dr. Kavita Rao",
        specialty: "Pediatrics",
        qualification: "MBBS, MD Pediatrics",
        experience: "8 years",
        availability: "Available today",
        verified: true,
      },
    ],
  },

  {
    id: 4,
    name: "Apollo Care Hospital",
    location: "Indore, Madhya Pradesh",
    address: "Super Corridor, Indore, Madhya Pradesh",
    coordinates: { lat: 22.7533, lng: 75.8040 },
    phone: "+91 91234 56789",
    distance: "8.2 km",
    rating: 4.6,
    reviews: 412,

    specialties: [
      "Cardiology",
      "Neurology",
      "Pediatrics",
    ],

    services: [
      "Emergency",
      "ICU",
      "Diagnostics",
      "Pharmacy",
    ],

    wait: "35 min",
    queue: 15,
    beds: 20,
    emergency: "Available",
    updated: "24 seconds ago",
    status: "Open",
    hours: "Open 24 hours",

    reviewInsights: [
      "Large number of available beds",
      "Multiple specialist departments",
      "Strong patient reviews",
    ],

    doctors: [
      {
        name: "Dr. Sameer Singh",
        specialty: "Cardiology",
        qualification: "MBBS, MD, DM Cardiology",
        experience: "16 years",
        availability: "Available today",
        verified: true,
      },
      {
        name: "Dr. Riya Sharma",
        specialty: "Pediatrics",
        qualification: "MBBS, MD Pediatrics",
        experience: "7 years",
        availability: "Available today",
        verified: true,
      },
    ],
  },
];

/* =========================================================
   MAIN APP
   ========================================================= */

function App() {
  const [page, setPage] = useState("dashboard");

  const [selectedHospital, setSelectedHospital] =
    useState(null);

  const [compareIds, setCompareIds] = useState([]);

  const [search, setSearch] = useState("");

  const [specialty, setSpecialty] =
    useState("All Specialties");

  const [service, setService] =
    useState("All Services");

  const [status, setStatus] =
    useState("All");

  const [userLocation, setUserLocation] = useState(null);
  const [locationStatus, setLocationStatus] = useState("idle");
  const [locationError, setLocationError] = useState("");

  const [appointment, setAppointment] = useState(() => {
    try {
      const saved = localStorage.getItem(
        "smartHospitalAppointment"
      );

      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const [queueData, setQueueData] = useState(() => {
    try {
      const saved = localStorage.getItem(
        "smartHospitalQueue"
      );

      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const [notifications, setNotifications] = useState(() => {
    try {
      const saved = localStorage.getItem(
        "smartHospitalNotifications"
      );

      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  /* ---------------------------------------------------------
     SAVE DATA
     --------------------------------------------------------- */

  useEffect(() => {
    if (appointment) {
      localStorage.setItem(
        "smartHospitalAppointment",
        JSON.stringify(appointment)
      );
    } else {
      localStorage.removeItem(
        "smartHospitalAppointment"
      );
    }
  }, [appointment]);

  useEffect(() => {
    if (queueData) {
      localStorage.setItem(
        "smartHospitalQueue",
        JSON.stringify(queueData)
      );
    } else {
      localStorage.removeItem("smartHospitalQueue");
    }
  }, [queueData]);

  useEffect(() => {
    localStorage.setItem(
      "smartHospitalNotifications",
      JSON.stringify(notifications)
    );
  }, [notifications]);

  /* ---------------------------------------------------------
     NOTIFICATION HELPER
     --------------------------------------------------------- */

  function addNotification(title, message) {
    setNotifications((previous) => [
      {
        id: Date.now(),
        title,
        message,
        time: new Date().toLocaleString(),
        unread: true,
      },
      ...previous,
    ]);
  }

  /* ---------------------------------------------------------
     GPS LOCATION + DISTANCE
     --------------------------------------------------------- */

  function getDistanceKm(from, to) {
    const radians = (degrees) => (degrees * Math.PI) / 180;
    const earthRadiusKm = 6371;
    const dLat = radians(to.lat - from.lat);
    const dLng = radians(to.lng - from.lng);
    const a =
      Math.sin(dLat / 2) ** 2 +
      Math.cos(radians(from.lat)) *
        Math.cos(radians(to.lat)) *
        Math.sin(dLng / 2) ** 2;
    return earthRadiusKm * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  }

  function useCurrentLocation() {
    setLocationError("");
    if (!navigator.geolocation) {
      setLocationStatus("error");
      setLocationError("Geolocation is not supported by this browser.");
      return;
    }
    setLocationStatus("loading");
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setUserLocation({
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        });
        setLocationStatus("ready");
        setLocationError("");
        addNotification("Location updated", "Your current location was received. Hospital distances can now be estimated.");
      },
      (error) => {
        setLocationStatus("error");
        const messages = {
          1: "Location permission was denied. Allow location access in your browser settings and try again.",
          2: "Your location is currently unavailable. Check your device's location services and try again.",
          3: "Getting your location timed out. Please try again.",
        };
        setLocationError(messages[error.code] || "Unable to get your location. Please try again.");
      },
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 60000 }
    );
  }

  const hospitalsWithDistance = hospitals.map((hospital) => ({
    ...hospital,
    distance: userLocation && hospital.coordinates
      ? `${getDistanceKm(userLocation, hospital.coordinates).toFixed(1)} km`
      : hospital.distance,
    distanceKm: userLocation && hospital.coordinates
      ? getDistanceKm(userLocation, hospital.coordinates)
      : Number.parseFloat(hospital.distance),
  }));

  /* ---------------------------------------------------------
     HOSPITAL COMPARISON
     --------------------------------------------------------- */

  function toggleCompare(hospitalId) {
    setCompareIds((previous) => {
      if (previous.includes(hospitalId)) {
        return previous.filter((id) => id !== hospitalId);
      }
      if (previous.length >= 3) {
        return previous;
      }
      return [...previous, hospitalId];
    });
  }

  const hospitalsToCompare = hospitalsWithDistance.filter((hospital) =>
    compareIds.includes(hospital.id)
  );

  /* ---------------------------------------------------------
     OPEN HOSPITAL
     --------------------------------------------------------- */

  function openHospital(hospital) {
    setSelectedHospital(hospital);
    setPage("details");
    window.scrollTo(0, 0);
  }

  /* ---------------------------------------------------------
     BOOK APPOINTMENT
     --------------------------------------------------------- */

  function startBooking(hospital) {
    setSelectedHospital(hospital);
    setPage("booking");
    window.scrollTo(0, 0);
  }

  function confirmAppointment(data) {
    const newAppointment = {
      id: Date.now(),
      hospitalId: selectedHospital.id,
      hospitalName: selectedHospital.name,

      doctor: data.doctor.name,
      specialty: data.doctor.specialty,

      date: data.date,
      time: data.time,

      patientName: data.patientName,
      phone: data.phone,

      status: "Confirmed",
    };

    setAppointment(newAppointment);

    addNotification(
      "Appointment confirmed",
      `${data.doctor.name} • ${data.date} • ${data.time}`
    );

    setPage("appointment-confirmed");

    window.scrollTo(0, 0);
  }

  /* ---------------------------------------------------------
     JOIN QUEUE
     --------------------------------------------------------- */

  function joinQueue(hospital) {
    const doctor =
      hospital.doctors.find(
        (item) =>
          item.specialty ===
          hospital.specialties[0]
      ) || hospital.doctors[0];

    const tokenNumber =
      Math.floor(Math.random() * 20) + 64;

    const newQueue = {
      id: Date.now(),
      hospitalId: hospital.id,
      hospitalName: hospital.name,

      token: `Q${tokenNumber}`,

      doctor: doctor.name,
      specialty: doctor.specialty,

      peopleAhead: 1,
      estimatedWait: 3,
      currentToken: tokenNumber - 1,

      status: "Active",
      lastUpdated: "Just now",
    };

    setQueueData(newQueue);

    addNotification(
      "Queue joined",
      `Your token is ${newQueue.token} at ${hospital.name}`
    );

    setPage("queue");

    window.scrollTo(0, 0);
  }

  /* ---------------------------------------------------------
     QUEUE SIMULATION
     --------------------------------------------------------- */

  function simulateQueueUpdate() {
    if (!queueData) return;

    const newPeopleAhead =
      Math.max(0, queueData.peopleAhead - 1);

    const newWait =
      Math.max(0, queueData.estimatedWait - 2);

    const newCurrentToken =
      queueData.currentToken + 1;

    const updatedQueue = {
      ...queueData,

      peopleAhead: newPeopleAhead,
      estimatedWait: newWait,
      currentToken: newCurrentToken,
      lastUpdated: "Just now",
    };

    setQueueData(updatedQueue);

    addNotification(
      "Queue updated",
      newPeopleAhead === 0
        ? "You are next in the queue."
        : `${newPeopleAhead} patient(s) ahead of you.`
    );
  }

  /* ---------------------------------------------------------
     CANCEL APPOINTMENT
     --------------------------------------------------------- */

  function cancelAppointment() {
    setAppointment(null);

    addNotification(
      "Appointment cancelled",
      "Your upcoming appointment has been cancelled."
    );
  }

  /* ---------------------------------------------------------
     LEAVE QUEUE
     --------------------------------------------------------- */

  function leaveQueue() {
    setQueueData(null);

    addNotification(
      "Queue left",
      "You have left the hospital queue."
    );

    setPage("dashboard");
  }

  /* ---------------------------------------------------------
     FILTER HOSPITALS
     --------------------------------------------------------- */

  const filteredHospitals = hospitalsWithDistance.filter(
    (hospital) => {
      const text = search.toLowerCase().trim();

      const matchesSearch =
        hospital.name
          .toLowerCase()
          .includes(text) ||
        hospital.location
          .toLowerCase()
          .includes(text) ||
        hospital.specialties.some((item) =>
          item.toLowerCase().includes(text)
        );

      const matchesSpecialty =
        specialty === "All Specialties" ||
        hospital.specialties.includes(
          specialty
        );

      const matchesService =
        service === "All Services" ||
        hospital.services.includes(service);

      const matchesStatus =
        status === "All" ||
        hospital.status === status;

      return (
        matchesSearch &&
        matchesSpecialty &&
        matchesService &&
        matchesStatus
      );
    }
  );

  if (userLocation) {
    filteredHospitals.sort((a, b) => a.distanceKm - b.distanceKm);
  }

  /* =========================================================
     DASHBOARD
     ========================================================= */

  if (page === "staff") {
    return <HospitalStaffDashboard onBack={() => setPage("dashboard")} />;
  }

  if (page === "dashboard") {
    return (
      <>
      <PatientDashboard
        appointment={appointment}
        queueData={queueData}
        notifications={notifications}
        locationStatus={locationStatus}
        locationError={locationError}
        onUseLocation={useCurrentLocation}
        onFindHospital={() => {
          setPage("search");
          window.scrollTo(0, 0);
        }}
        onHospitalSelect={(hospitalId) => {
          const hospital = hospitalsWithDistance.find(
            (item) => item.id === hospitalId
          );

          if (hospital) {
            openHospital(hospital);
          }
        }}
        onTrackQueue={() => {
          if (queueData) {
            setPage("queue");
            window.scrollTo(0, 0);
          }
        }}
        onViewAppointment={() => {
          if (appointment) {
            setPage("appointment-confirmed");
            window.scrollTo(0, 0);
          }
        }}
        onProfile={() => {
          setPage("profile");
          window.scrollTo(0, 0);
        }}
        onNotifications={() => {
          setPage("notifications");
          window.scrollTo(0, 0);
        }}
        onCancelAppointment={cancelAppointment}
        onLeaveQueue={leaveQueue}
      />
      <button onClick={() => { setPage("staff"); window.scrollTo(0, 0); }} className="fixed bottom-5 right-5 z-50 rounded-full bg-slate-950 px-5 py-3 text-sm font-semibold text-white shadow-xl hover:bg-blue-800">Hospital Staff Portal</button>
      </>
    );
  }

  /* =========================================================
     SEARCH
     ========================================================= */

  if (page === "search") {
    return (
      <HospitalSearch
        search={search}
        setSearch={setSearch}
        specialty={specialty}
        setSpecialty={setSpecialty}
        service={service}
        setService={setService}
        status={status}
        setStatus={setStatus}
        hospitals={filteredHospitals}
        compareIds={compareIds}
        onToggleCompare={toggleCompare}
        onOpenCompare={() => { setPage("compare"); window.scrollTo(0, 0); }}
        onBack={() => setPage("dashboard")}
        onDashboard={() => setPage("dashboard")}
        onViewHospital={openHospital}
      />
    );
  }

  /* =========================================================
     HOSPITAL COMPARISON
     ========================================================= */

  if (page === "compare") {
    return (
      <HospitalComparison
        hospitals={hospitalsToCompare}
        onBack={() => setPage("search")}
        onDashboard={() => setPage("dashboard")}
        onRemove={toggleCompare}
        onViewHospital={openHospital}
      />
    );
  }

  /* =========================================================
     HOSPITAL DETAILS
     ========================================================= */

  if (
    page === "details" &&
    selectedHospital
  ) {
    return (
      <HospitalDetails
        hospital={selectedHospital}
        onBack={() => setPage("search")}
        onDashboard={() => setPage("dashboard")}
        onBook={() =>
          startBooking(selectedHospital)
        }
        onQueue={() =>
          joinQueue(selectedHospital)
        }
      />
    );
  }

  /* =========================================================
     APPOINTMENT BOOKING
     ========================================================= */

  if (
    page === "booking" &&
    selectedHospital
  ) {
    return (
      <AppointmentBooking
        hospital={selectedHospital}
        onBack={() => setPage("details")}
        onConfirm={confirmAppointment}
      />
    );
  }

  /* =========================================================
     APPOINTMENT CONFIRMED
     ========================================================= */

  if (
    page === "appointment-confirmed" &&
    appointment
  ) {
    return (
      <AppointmentConfirmed
        appointment={appointment}
        onDashboard={() => setPage("dashboard")}
        onHospital={() => {
          const hospital = hospitals.find(
            (item) =>
              item.id === appointment.hospitalId
          );

          if (hospital) {
            openHospital(hospital);
          }
        }}
      />
    );
  }

  /* =========================================================
     QUEUE
     ========================================================= */

  if (page === "queue" && queueData) {
    return (
      <QueueTracking
        queueData={queueData}
        onDashboard={() => setPage("dashboard")}
        onBack={() => {
          const hospital = hospitals.find(
            (item) =>
              item.id === queueData.hospitalId
          );

          if (hospital) {
            openHospital(hospital);
          } else {
            setPage("dashboard");
          }
        }}
        onUpdate={simulateQueueUpdate}
        onLeave={leaveQueue}
      />
    );
  }

  /* =========================================================
     PROFILE
     ========================================================= */

  if (page === "profile") {
    return (
      <ProfilePage
        appointment={appointment}
        queueData={queueData}
        notifications={notifications}
        onDashboard={() => setPage("dashboard")}
        onFindHospital={() => setPage("search")}
        onAppointment={() =>
          appointment &&
          setPage("appointment-confirmed")
        }
        onQueue={() =>
          queueData && setPage("queue")
        }
      />
    );
  }

  /* =========================================================
     NOTIFICATIONS
     ========================================================= */

  if (page === "notifications") {
    return (
      <NotificationsPage
        notifications={notifications}
        onBack={() => setPage("dashboard")}
        onMarkAllRead={() => setNotifications((items) => items.map((item) => ({ ...item, unread: false })))}
        onClear={() => setNotifications([])}
        onMarkRead={(id) => setNotifications((items) => items.map((item) => item.id === id ? { ...item, unread: false } : item))}
      />
    );
  }

  return null;
}

/* =========================================================
   HOSPITAL SEARCH
   ========================================================= */

function HospitalSearch({
  search,
  setSearch,
  specialty,
  setSpecialty,
  service,
  setService,
  status,
  setStatus,
  hospitals,
  compareIds = [],
  onToggleCompare,
  onOpenCompare,
  onBack,
  onDashboard,
  onViewHospital,
}) {
  return (
    <div className="min-h-screen bg-slate-950 text-white">

      <Navbar
        onDashboard={onDashboard}
      />

      <main className="max-w-7xl mx-auto px-6 py-10">

        <button
          type="button"
          onClick={onBack}
          className="flex items-center gap-2 text-slate-400 hover:text-white mb-8"
        >
          <ArrowLeft size={18} />
          Back to Dashboard
        </button>

        <p className="text-blue-400 font-semibold">
          FIND HOSPITALS
        </p>

        <h1 className="text-4xl md:text-5xl font-bold mt-2">
          Find a Hospital
        </h1>

        <p className="text-slate-400 mt-3 max-w-2xl">
          Search hospitals by location, specialty and
          services. View queues, waiting times, beds,
          specialists and patient reviews.
        </p>

        {/* SEARCH */}

        <div className="mt-8 bg-white rounded-2xl p-2 flex items-center">

          <Search
            size={22}
            className="text-slate-400 ml-3"
          />

          <input
            value={search}
            onChange={(e) =>
              setSearch(e.target.value)
            }
            placeholder="Search hospital, specialty or location..."
            className="flex-1 px-4 py-4 text-slate-800 outline-none"
          />

          <button
            type="button"
            className="bg-blue-600 text-white px-7 py-4 rounded-xl font-semibold"
          >
            Search
          </button>

        </div>

        {/* FILTERS */}

        <div className="mt-6 bg-slate-900 border border-slate-800 rounded-2xl p-5">

          <div className="flex items-center gap-2 mb-4">
            <Filter
              size={19}
              className="text-blue-400"
            />
            <span className="font-semibold">
              Filters
            </span>
          </div>

          <div className="grid md:grid-cols-3 gap-4">

            <select
              value={specialty}
              onChange={(e) =>
                setSpecialty(e.target.value)
              }
              className="bg-slate-950 border border-slate-700 rounded-xl px-4 py-3"
            >
              <option>All Specialties</option>
              <option>Cardiology</option>
              <option>Neurology</option>
              <option>Orthopedics</option>
              <option>Pediatrics</option>
              <option>Dermatology</option>
              <option>General Medicine</option>
            </select>

            <select
              value={service}
              onChange={(e) =>
                setService(e.target.value)
              }
              className="bg-slate-950 border border-slate-700 rounded-xl px-4 py-3"
            >
              <option>All Services</option>
              <option>Emergency</option>
              <option>Diagnostics</option>
              <option>ICU</option>
              <option>Pharmacy</option>
            </select>

            <select
              value={status}
              onChange={(e) =>
                setStatus(e.target.value)
              }
              className="bg-slate-950 border border-slate-700 rounded-xl px-4 py-3"
            >
              <option>All</option>
              <option>Open</option>
              <option>Closed</option>
            </select>

          </div>
        </div>

        {/* LOCATION */}

        <div className="flex items-center gap-2 text-blue-400 mt-7">
          <MapPin size={18} />
          Showing hospitals near Indore
        </div>

        {/* RESULT COUNT */}

        <div className="flex justify-between items-center mt-10 mb-5">

          <h2 className="text-2xl font-bold">
            {hospitals.length} Hospitals Found
          </h2>

          <span className="text-sm text-slate-500">
            Availability updated in real time
          </span>

        </div>

        {compareIds.length > 0 && (
          <div className="mb-5 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 rounded-2xl border border-blue-500/30 bg-blue-500/10 p-4">
            <div className="flex items-center gap-3">
              <GitCompare className="text-blue-300" size={21} />
              <div>
                <p className="font-semibold">{compareIds.length} of 3 hospitals selected</p>
                <p className="text-sm text-slate-400">Select at least 2 hospitals to compare their details.</p>
              </div>
            </div>
            <button
              type="button"
              disabled={compareIds.length < 2}
              onClick={onOpenCompare}
              className="rounded-xl bg-blue-600 px-5 py-3 font-semibold hover:bg-blue-700 disabled:cursor-not-allowed disabled:opacity-40"
            >
              Compare hospitals
            </button>
          </div>
        )}

        {/* HOSPITALS */}

        <div className="space-y-5">

          {hospitals.map((hospital) => (
            <HospitalCard
              key={hospital.id}
              hospital={hospital}
              onView={onViewHospital}
              isCompared={compareIds.includes(hospital.id)}
              canSelectCompare={compareIds.length < 3 || compareIds.includes(hospital.id)}
              onToggleCompare={onToggleCompare}
            />
          ))}

        </div>

        {hospitals.length === 0 && (
          <div className="text-center py-20 text-slate-400">
            No hospitals match your search.
          </div>
        )}

      </main>
    </div>
  );
}

/* =========================================================
   HOSPITAL CARD
   ========================================================= */

function HospitalCard({
  hospital,
  onView,
  isCompared = false,
  canSelectCompare = true,
  onToggleCompare,
}) {
  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 hover:border-blue-500/50 transition">

      <div className="flex flex-col lg:flex-row lg:justify-between gap-5">

        <div>

          <div className="flex items-center gap-3 flex-wrap">

            <h2 className="text-xl font-bold">
              {hospital.name}
            </h2>

            <span className="bg-green-500/10 text-green-400 border border-green-500/20 px-2 py-1 rounded-full text-xs">
              {hospital.status}
            </span>

          </div>

          <div className="flex items-center gap-2 text-slate-400 mt-3">
            <MapPin size={16} />
            {hospital.location}
            <span>•</span>
            {hospital.distance}
          </div>

          <div className="flex items-center gap-2 mt-3">

            <Star
              size={17}
              className="text-yellow-400 fill-yellow-400"
            />

            <span className="font-semibold">
              {hospital.rating}
            </span>

            <span className="text-slate-500">
              ({hospital.reviews} reviews)
            </span>

          </div>

        </div>

        <div className="bg-blue-500/10 border border-blue-500/20 rounded-xl px-5 py-3 h-fit">

          <p className="text-sm text-slate-400">
            Estimated wait
          </p>

          <p className="text-2xl font-bold text-blue-400">
            {hospital.wait}
          </p>

        </div>

      </div>

      <div className="grid md:grid-cols-3 gap-3 mt-6">

        <InfoBox
          icon={<Users size={18} />}
          title="Queue"
          value={`${hospital.queue} patients`}
        />

        <InfoBox
          icon={<Bed size={18} />}
          title="Beds"
          value={`${hospital.beds} available`}
        />

        <InfoBox
          icon={<ShieldCheck size={18} />}
          title="Emergency"
          value={hospital.emergency}
        />

      </div>

      <div className="flex flex-wrap gap-2 mt-5">

        {hospital.specialties.map(
          (item) => (
            <span
              key={item}
              className="bg-blue-500/10 text-blue-300 px-3 py-1.5 rounded-full text-sm"
            >
              {item}
            </span>
          )
        )}

      </div>

      <div className="flex justify-between items-center mt-6 pt-5 border-t border-slate-800">

        <span className="text-xs text-slate-500">
          Updated {hospital.updated}
        </span>

        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={() => onToggleCompare?.(hospital.id)}
            disabled={!canSelectCompare}
            aria-pressed={isCompared}
            className={`rounded-xl border px-4 py-2.5 font-semibold transition disabled:cursor-not-allowed disabled:opacity-40 ${isCompared ? "border-blue-400 bg-blue-500/15 text-blue-300" : "border-slate-700 text-slate-300 hover:border-blue-400"}`}
          >
            <span className="inline-flex items-center gap-2">
              <GitCompare size={16} />
              {isCompared ? "Selected" : "Compare"}
            </span>
          </button>
          <button
            type="button"
            onClick={() => onView(hospital)}
            className="bg-blue-600 hover:bg-blue-700 px-5 py-2.5 rounded-xl font-semibold"
          >
            View Hospital
          </button>
        </div>

      </div>

    </div>
  );
}

/* =========================================================
   HOSPITAL COMPARISON PAGE
   ========================================================= */

function HospitalComparison({ hospitals, onBack, onDashboard, onRemove, onViewHospital }) {
  const rows = [
    ["Location", (hospital) => hospital.location],
    ["Distance", (hospital) => hospital.distance || "Not available"],
    ["Rating", (hospital) => `${hospital.rating} / 5 (${hospital.reviews} reviews)`],
    ["Estimated wait", (hospital) => hospital.wait],
    ["Queue", (hospital) => `${hospital.queue} patients`],
    ["Available beds", (hospital) => `${hospital.beds}`],
    ["Emergency", (hospital) => hospital.emergency],
    ["Status", (hospital) => hospital.status],
    ["Specialties", (hospital) => hospital.specialties.join(", ")],
    ["Services", (hospital) => hospital.services.join(", ")],
    ["Operating hours", (hospital) => hospital.hours || "Not specified"],
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      <Navbar onDashboard={onDashboard} />
      <main className="mx-auto max-w-7xl px-6 py-10">
        <button type="button" onClick={onBack} className="mb-8 flex items-center gap-2 text-slate-400 hover:text-white">
          <ArrowLeft size={18} /> Back to Hospitals
        </button>
        <div className="mb-8 flex items-start gap-3">
          <GitCompare className="mt-2 text-blue-400" size={30} />
          <div>
            <p className="font-semibold text-blue-400">HOSPITAL COMPARISON</p>
            <h1 className="mt-2 text-3xl font-bold md:text-4xl">Compare hospitals side by side</h1>
            <p className="mt-3 max-w-3xl text-slate-400">Review distance, waiting time, available beds, emergency services and other listed information. Data shown here is demo data and may not reflect live hospital conditions.</p>
          </div>
        </div>

        {hospitals.length < 2 ? (
          <div className="rounded-2xl border border-slate-800 bg-slate-900 p-8 text-center">
            <p className="text-lg font-semibold">Select at least 2 hospitals to compare.</p>
            <button type="button" onClick={onBack} className="mt-5 rounded-xl bg-blue-600 px-5 py-3 font-semibold hover:bg-blue-700">Choose hospitals</button>
          </div>
        ) : (
          <div className="overflow-x-auto rounded-2xl border border-slate-800 bg-slate-900">
            <table className="w-full min-w-[760px] border-collapse text-left">
              <thead>
                <tr>
                  <th className="w-48 border-b border-slate-800 bg-slate-900 p-4 text-sm text-slate-400">Feature</th>
                  {hospitals.map((hospital) => (
                    <th key={hospital.id} className="min-w-56 border-b border-l border-slate-800 p-4 align-top">
                      <h2 className="text-lg font-bold">{hospital.name}</h2>
                      <div className="mt-4 flex flex-wrap gap-2">
                        <button type="button" onClick={() => onViewHospital(hospital)} className="rounded-lg bg-blue-600 px-3 py-2 text-sm font-semibold hover:bg-blue-700">View details</button>
                        <button type="button" onClick={() => onRemove(hospital.id)} className="rounded-lg border border-slate-700 px-3 py-2 text-sm text-slate-300 hover:border-red-400 hover:text-red-300">Remove</button>
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {rows.map(([label, value], index) => (
                  <tr key={label} className={index % 2 === 0 ? "bg-slate-950/40" : ""}>
                    <th scope="row" className="border-t border-slate-800 p-4 text-sm font-semibold text-slate-300">{label}</th>
                    {hospitals.map((hospital) => (
                      <td key={hospital.id} className="border-l border-t border-slate-800 p-4 text-sm leading-6 text-slate-200">{value(hospital)}</td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        <p className="mt-5 text-xs text-slate-500">Comparison is informational only. In emergencies, contact emergency services and follow professional medical guidance.</p>
      </main>
    </div>
  );
}

/* =========================================================
   HOSPITAL DETAILS
   ========================================================= */

function HospitalDetails({
  hospital,
  onBack,
  onDashboard,
  onBook,
  onQueue,
}) {
  return (
    <div className="min-h-screen bg-slate-950 text-white">

      <Navbar
        onDashboard={onDashboard}
      />

      <main className="max-w-7xl mx-auto px-6 py-10">

        <button
          type="button"
          onClick={onBack}
          className="flex items-center gap-2 text-slate-400 hover:text-white mb-8"
        >
          <ArrowLeft size={18} />
          Back to Hospitals
        </button>

        {/* HEADER */}

        <section className="bg-slate-900 border border-slate-800 rounded-3xl p-8">

          <div className="flex flex-col lg:flex-row justify-between gap-7">

            <div>

              <div className="flex items-center gap-3 flex-wrap">

                <h1 className="text-4xl font-bold">
                  {hospital.name}
                </h1>

                <span className="bg-green-500/10 text-green-400 border border-green-500/20 px-3 py-1 rounded-full text-sm">
                  {hospital.status}
                </span>

              </div>

              <div className="flex items-center gap-2 text-slate-400 mt-4">
                <MapPin size={18} />
                {hospital.location}
              </div>

              <div className="flex items-center gap-3 mt-4">

                <Star
                  size={19}
                  className="text-yellow-400 fill-yellow-400"
                />

                <span className="font-semibold">
                  {hospital.rating}
                </span>

                <span className="text-slate-500">
                  {hospital.reviews} reviews
                </span>

                <span className="text-slate-500">
                  • {hospital.distance}
                </span>

              </div>

            </div>

            <div className="flex flex-wrap gap-3">

              <button
                type="button"
                onClick={onBook}
                className="bg-blue-600 hover:bg-blue-700 px-5 py-3 rounded-xl font-semibold flex items-center gap-2"
              >
                <Calendar size={19} />
                Book Appointment
              </button>

              <button
                type="button"
                onClick={onQueue}
                className="bg-green-600 hover:bg-green-700 px-5 py-3 rounded-xl font-semibold flex items-center gap-2"
              >
                <Users size={19} />
                Join Live Queue
              </button>

            </div>

          </div>

          {/* LIVE STATUS */}

          <div className="grid md:grid-cols-4 gap-4 mt-8">

            <InfoBox
              icon={<Clock3 size={20} />}
              title="Estimated Wait"
              value={hospital.wait}
            />

            <InfoBox
              icon={<Users size={20} />}
              title="Queue"
              value={`${hospital.queue} patients`}
            />

            <InfoBox
              icon={<Bed size={20} />}
              title="Beds Available"
              value={hospital.beds}
            />

            <InfoBox
              icon={<ShieldCheck size={20} />}
              title="Emergency"
              value={hospital.emergency}
            />

          </div>

        </section>

        {/* LOWER CONTENT */}

        <div className="grid lg:grid-cols-2 gap-6 mt-6">

          {/* SPECIALISTS */}

          <section className="bg-slate-900 border border-slate-800 rounded-2xl p-6">

            <h2 className="text-2xl font-bold mb-5">
              Available Specialists
            </h2>

            <div className="space-y-4">

              {hospital.doctors.map(
                (doctor) => (

                  <div
                    key={doctor.name}
                    className="bg-slate-950 border border-slate-800 rounded-xl p-5"
                  >

                    <div className="flex justify-between gap-4">

                      <div>

                        <h3 className="text-lg font-bold">
                          {doctor.name}
                        </h3>

                        <p className="text-blue-400 mt-1">
                          {doctor.specialty}
                        </p>

                        <p className="text-slate-400 text-sm mt-2">
                          {doctor.qualification}
                        </p>

                        <p className="text-slate-500 text-sm mt-1">
                          {doctor.experience} experience
                        </p>

                      </div>

                      {doctor.verified && (
                        <div className="text-center">

                          <ShieldCheck
                            size={24}
                            className="text-green-400 mx-auto"
                          />

                          <span className="text-xs text-green-400">
                            Verified
                          </span>

                        </div>
                      )}

                    </div>

                    <p className="text-green-400 text-sm mt-4">
                      {doctor.availability}
                    </p>

                  </div>

                )
              )}

            </div>

          </section>

          {/* REVIEWS */}

          <section className="bg-slate-900 border border-slate-800 rounded-2xl p-6">

            <h2 className="text-2xl font-bold">
              Services & Reviews
            </h2>

            <div className="flex flex-wrap gap-2 mt-5">

              {hospital.services.map(
                (service) => (
                  <span
                    key={service}
                    className="bg-blue-500/10 text-blue-300 px-4 py-2 rounded-full"
                  >
                    {service}
                  </span>
                )
              )}

            </div>

            <div className="bg-slate-950 rounded-xl p-5 mt-6">

              <div className="flex items-center gap-3">

                <Star
                  size={25}
                  className="text-yellow-400 fill-yellow-400"
                />

                <span className="text-3xl font-bold">
                  {hospital.rating}
                </span>

                <span className="text-slate-500">
                  / 5
                </span>

              </div>

              <p className="text-slate-400 mt-3">
                Based on {hospital.reviews} patient reviews.
              </p>

              <div className="grid grid-cols-3 gap-3 mt-5">

                <ReviewScore
                  label="Doctors"
                  value="4.8"
                />

                <ReviewScore
                  label="Service"
                  value="4.7"
                />

                <ReviewScore
                  label="Cleanliness"
                  value="4.6"
                />

              </div>

            </div>

            <div className="mt-6">

              <h3 className="font-semibold">
                Patient Review Insights
              </h3>

              <ul className="mt-3 space-y-2 text-sm text-slate-400">

                {hospital.reviewInsights.map(
                  (item) => (
                    <li key={item}>
                      • {item}
                    </li>
                  )
                )}

              </ul>

            </div>

          </section>

        </div>

        {/* WHY THIS HOSPITAL */}

        <section className="bg-slate-900 border border-slate-800 rounded-2xl p-6 mt-6">

          <h2 className="text-2xl font-bold">
            Why this hospital?
          </h2>

          <p className="text-slate-400 mt-2">
            These factors are shown to help you compare
            hospitals. They do not replace medical advice.
          </p>

          <div className="grid md:grid-cols-4 gap-4 mt-6">

            <Reason
              title="Distance"
              value={hospital.distance}
            />

            <Reason
              title="Waiting Time"
              value={hospital.wait}
            />

            <Reason
              title="Patient Rating"
              value={`${hospital.rating}/5`}
            />

            <Reason
              title="Beds"
              value={`${hospital.beds} available`}
            />

          </div>

        </section>

        {/* LOCATION */}

        <section className="bg-slate-900 border border-slate-800 rounded-2xl p-6 mt-6">

          <h2 className="text-2xl font-bold">
            Location & Contact
          </h2>

          <p className="text-slate-400 mt-4">
            {hospital.address}
          </p>

          <p className="text-slate-400 mt-2">
            {hospital.hours}
          </p>

          <div className="flex flex-wrap gap-3 mt-5">

            <button
              type="button"
              onClick={() =>
                window.open(
                  `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
                    hospital.address
                  )}`,
                  "_blank"
                )
              }
              className="bg-blue-600 hover:bg-blue-700 px-5 py-3 rounded-xl font-semibold flex items-center gap-2"
            >
              <Navigation size={19} />
              Get Directions
            </button>

            <button
              type="button"
              onClick={() => {
                window.location.href =
                  `tel:${hospital.phone}`;
              }}
              className="bg-slate-800 hover:bg-slate-700 px-5 py-3 rounded-xl font-semibold flex items-center gap-2"
            >
              <Phone size={19} />
              Contact
            </button>

          </div>

          <p className="text-xs text-slate-500 mt-5">
            Information updated {hospital.updated}.
          </p>

        </section>

      </main>
    </div>
  );
}

/* =========================================================
   APPOINTMENT BOOKING
   ========================================================= */

function AppointmentBooking({
  hospital,
  onBack,
  onConfirm,
}) {
  const [doctorId, setDoctorId] =
    useState(0);

  const [date, setDate] =
    useState("");

  const [time, setTime] =
    useState("");

  const [patientName, setPatientName] =
    useState("Tushar");

  const [phone, setPhone] =
    useState("");

  const doctor =
    hospital.doctors[doctorId];

  const availableTimes = [
    "09:00 AM",
    "10:00 AM",
    "11:30 AM",
    "02:00 PM",
    "04:30 PM",
  ];

  function handleSubmit(e) {
    e.preventDefault();

    if (!date || !time || !patientName || !phone) {
      alert(
        "Please fill all appointment details."
      );
      return;
    }

    onConfirm({
      doctor,
      date,
      time,
      patientName,
      phone,
    });
  }

  return (
    <div className="min-h-screen bg-slate-950 text-white">

      <Navbar />

      <main className="max-w-4xl mx-auto px-6 py-10">

        <button
          type="button"
          onClick={onBack}
          className="flex items-center gap-2 text-slate-400 hover:text-white mb-8"
        >
          <ArrowLeft size={18} />
          Back to Hospital
        </button>

        <p className="text-blue-400 font-semibold">
          BOOK APPOINTMENT
        </p>

        <h1 className="text-4xl font-bold mt-2">
          Book an Appointment
        </h1>

        <p className="text-slate-400 mt-2">
          {hospital.name}
        </p>

        <form
          onSubmit={handleSubmit}
          className="mt-8 space-y-6"
        >

          {/* DOCTOR */}

          <section className="bg-slate-900 border border-slate-800 rounded-2xl p-6">

            <h2 className="text-xl font-bold">
              1. Select Specialist
            </h2>

            <div className="grid md:grid-cols-2 gap-4 mt-5">

              {hospital.doctors.map(
                (item, index) => (

                  <button
                    type="button"
                    key={item.name}
                    onClick={() =>
                      setDoctorId(index)
                    }
                    className={`text-left p-5 rounded-xl border transition ${
                      doctorId === index
                        ? "border-blue-500 bg-blue-500/10"
                        : "border-slate-800 bg-slate-950"
                    }`}
                  >

                    <div className="flex justify-between">

                      <div>

                        <h3 className="font-bold">
                          {item.name}
                        </h3>

                        <p className="text-blue-400 mt-1">
                          {item.specialty}
                        </p>

                        <p className="text-sm text-slate-400 mt-2">
                          {item.qualification}
                        </p>

                      </div>

                      <ShieldCheck
                        className="text-green-400"
                        size={21}
                      />

                    </div>

                    <p className="text-green-400 text-sm mt-4">
                      {item.availability}
                    </p>

                  </button>

                )
              )}

            </div>

          </section>

          {/* DATE/TIME */}

          <section className="bg-slate-900 border border-slate-800 rounded-2xl p-6">

            <h2 className="text-xl font-bold">
              2. Select Date & Time
            </h2>

            <div className="grid md:grid-cols-2 gap-5 mt-5">

              <div>

                <label className="text-sm text-slate-400">
                  Appointment Date
                </label>

                <input
                  type="date"
                  value={date}
                  onChange={(e) =>
                    setDate(e.target.value)
                  }
                  min={
                    new Date()
                      .toISOString()
                      .split("T")[0]
                  }
                  className="w-full mt-2 bg-slate-950 border border-slate-700 rounded-xl px-4 py-3"
                />

              </div>

              <div>

                <label className="text-sm text-slate-400">
                  Appointment Time
                </label>

                <select
                  value={time}
                  onChange={(e) =>
                    setTime(e.target.value)
                  }
                  className="w-full mt-2 bg-slate-950 border border-slate-700 rounded-xl px-4 py-3"
                >

                  <option value="">
                    Select time
                  </option>

                  {availableTimes.map(
                    (item) => (
                      <option
                        key={item}
                        value={item}
                      >
                        {item}
                      </option>
                    )
                  )}

                </select>

              </div>

            </div>

          </section>

          {/* PATIENT */}

          <section className="bg-slate-900 border border-slate-800 rounded-2xl p-6">

            <h2 className="text-xl font-bold">
              3. Patient Details
            </h2>

            <div className="grid md:grid-cols-2 gap-5 mt-5">

              <div>

                <label className="text-sm text-slate-400">
                  Patient Name
                </label>

                <input
                  value={patientName}
                  onChange={(e) =>
                    setPatientName(
                      e.target.value
                    )
                  }
                  className="w-full mt-2 bg-slate-950 border border-slate-700 rounded-xl px-4 py-3"
                />

              </div>

              <div>

                <label className="text-sm text-slate-400">
                  Phone Number
                </label>

                <input
                  value={phone}
                  onChange={(e) =>
                    setPhone(e.target.value)
                  }
                  placeholder="Enter phone number"
                  className="w-full mt-2 bg-slate-950 border border-slate-700 rounded-xl px-4 py-3"
                />

              </div>

            </div>

          </section>

          {/* SUMMARY */}

          <section className="bg-blue-500/5 border border-blue-500/20 rounded-2xl p-6">

            <h2 className="font-bold">
              Appointment Summary
            </h2>

            <div className="mt-4 space-y-2 text-sm">

              <p>
                <span className="text-slate-500">
                  Hospital:
                </span>{" "}
                {hospital.name}
              </p>

              <p>
                <span className="text-slate-500">
                  Specialist:
                </span>{" "}
                {doctor.name}
              </p>

              <p>
                <span className="text-slate-500">
                  Department:
                </span>{" "}
                {doctor.specialty}
              </p>

              <p>
                <span className="text-slate-500">
                  Date:
                </span>{" "}
                {date || "Not selected"}
              </p>

              <p>
                <span className="text-slate-500">
                  Time:
                </span>{" "}
                {time || "Not selected"}
              </p>

            </div>

          </section>

          <button
            type="submit"
            className="w-full bg-blue-600 hover:bg-blue-700 py-4 rounded-xl font-bold text-lg"
          >
            Confirm Appointment
          </button>

        </form>

      </main>
    </div>
  );
}

/* =========================================================
   APPOINTMENT CONFIRMED
   ========================================================= */

function AppointmentConfirmed({
  appointment,
  onDashboard,
  onHospital,
}) {
  return (
    <div className="min-h-screen bg-slate-950 text-white">

      <Navbar onDashboard={onDashboard} />

      <main className="max-w-3xl mx-auto px-6 py-16">

        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-8 text-center">

          <div className="w-20 h-20 bg-green-500/10 rounded-full flex items-center justify-center mx-auto">

            <CheckCircle2
              size={45}
              className="text-green-400"
            />

          </div>

          <h1 className="text-3xl font-bold mt-6">
            Appointment Confirmed
          </h1>

          <p className="text-slate-400 mt-2">
            Your appointment has been successfully booked.
          </p>

          <div className="bg-slate-950 rounded-2xl p-6 text-left mt-8 space-y-4">

            <DetailRow
              label="Hospital"
              value={appointment.hospitalName}
            />

            <DetailRow
              label="Specialist"
              value={appointment.doctor}
            />

            <DetailRow
              label="Department"
              value={appointment.specialty}
            />

            <DetailRow
              label="Date"
              value={appointment.date}
            />

            <DetailRow
              label="Time"
              value={appointment.time}
            />

            <DetailRow
              label="Patient"
              value={appointment.patientName}
            />

            <DetailRow
              label="Status"
              value="Confirmed"
            />

          </div>

          <div className="flex flex-col sm:flex-row gap-3 mt-7">

            <button
              type="button"
              onClick={onDashboard}
              className="flex-1 bg-blue-600 hover:bg-blue-700 py-3 rounded-xl font-semibold"
            >
              Go to Dashboard
            </button>

            <button
              type="button"
              onClick={onHospital}
              className="flex-1 bg-slate-800 hover:bg-slate-700 py-3 rounded-xl font-semibold"
            >
              View Hospital
            </button>

          </div>

        </div>

      </main>
    </div>
  );
}

/* =========================================================
   QUEUE TRACKING
   ========================================================= */

function QueueTracking({
  queueData,
  onDashboard,
  onBack,
  onUpdate,
  onLeave,
}) {
  return (
    <div className="min-h-screen bg-slate-950 text-white">

      <Navbar onDashboard={onDashboard} />

      <main className="max-w-4xl mx-auto px-6 py-10">

        <button
          type="button"
          onClick={onBack}
          className="flex items-center gap-2 text-slate-400 hover:text-white mb-8"
        >
          <ArrowLeft size={18} />
          Back to Hospital
        </button>

        <p className="text-green-400 font-semibold">
          LIVE QUEUE
        </p>

        <h1 className="text-4xl font-bold mt-2">
          Your Queue
        </h1>

        <p className="text-slate-400 mt-2">
          {queueData.hospitalName}
        </p>

        <section className="bg-slate-900 border border-slate-800 rounded-3xl p-8 mt-8 text-center">

          <p className="text-slate-400">
            Your Token
          </p>

          <p className="text-6xl font-bold text-blue-400 mt-2">
            {queueData.token}
          </p>

          <div className="grid md:grid-cols-3 gap-4 mt-8">

            <InfoBox
              icon={<Users size={20} />}
              title="People Ahead"
              value={queueData.peopleAhead}
            />

            <InfoBox
              icon={<Clock3 size={20} />}
              title="Estimated Wait"
              value={`${queueData.estimatedWait} min`}
            />

            <InfoBox
              icon={<Activity size={20} />}
              title="Current Token"
              value={`Q${queueData.currentToken}`}
            />

          </div>

          <div className="bg-slate-950 rounded-xl p-5 mt-6 text-left">

            <p className="text-slate-500 text-sm">
              Specialist
            </p>

            <p className="font-bold mt-1">
              {queueData.doctor}
            </p>

            <p className="text-blue-400 text-sm mt-1">
              {queueData.specialty}
            </p>

            <p className="text-slate-500 text-xs mt-4">
              Last updated: {queueData.lastUpdated}
            </p>

          </div>

          <div className="flex items-center justify-center gap-2 text-green-400 mt-6">

            <span className="w-2 h-2 rounded-full bg-green-400" />

            Queue Active

          </div>

          <div className="flex flex-col sm:flex-row gap-3 mt-7">

            <button
              type="button"
              onClick={onUpdate}
              className="flex-1 bg-blue-600 hover:bg-blue-700 py-3 rounded-xl font-semibold"
            >
              Simulate Queue Update
            </button>

            <button
              type="button"
              onClick={onDashboard}
              className="flex-1 bg-slate-800 hover:bg-slate-700 py-3 rounded-xl font-semibold"
            >
              Dashboard
            </button>

          </div>

          <button
            type="button"
            onClick={onLeave}
            className="text-red-400 hover:text-red-300 text-sm mt-6"
          >
            Leave Queue
          </button>

        </section>

      </main>
    </div>
  );
}

/* =========================================================
   PROFILE
   ========================================================= */

function ProfilePage({
  appointment,
  queueData,
  notifications,
  onDashboard,
  onFindHospital,
  onAppointment,
  onQueue,
}) {
  return (
    <div className="min-h-screen bg-slate-950 text-white">

      <Navbar onDashboard={onDashboard} />

      <main className="max-w-5xl mx-auto px-6 py-10">

        <button
          type="button"
          onClick={onDashboard}
          className="flex items-center gap-2 text-slate-400 hover:text-white mb-8"
        >
          <ArrowLeft size={18} />
          Back to Dashboard
        </button>

        <p className="text-blue-400 font-semibold">
          PATIENT PROFILE
        </p>

        <h1 className="text-4xl font-bold mt-2">
          My Profile
        </h1>

        <div className="grid lg:grid-cols-3 gap-6 mt-8">

          {/* PROFILE CARD */}

          <section className="bg-slate-900 border border-slate-800 rounded-2xl p-6">

            <div className="w-20 h-20 bg-blue-600 rounded-full flex items-center justify-center text-3xl font-bold">
              T
            </div>

            <h2 className="text-2xl font-bold mt-5">
              Tushar
            </h2>

            <p className="text-slate-400 mt-1">
              Patient
            </p>

            <div className="border-t border-slate-800 mt-6 pt-5 space-y-4">

              <DetailRow
                label="Account"
                value="Active"
              />

              <DetailRow
                label="Role"
                value="Patient"
              />

              <DetailRow
                label="Notifications"
                value={`${notifications.length}`}
              />

            </div>

          </section>

          {/* APPOINTMENT */}

          <section className="bg-slate-900 border border-slate-800 rounded-2xl p-6">

            <h2 className="text-xl font-bold">
              Appointment
            </h2>

            {appointment ? (
              <div className="mt-5">

                <div className="bg-slate-950 rounded-xl p-5">

                  <p className="font-bold">
                    {appointment.hospitalName}
                  </p>

                  <p className="text-blue-400 text-sm mt-2">
                    {appointment.doctor}
                  </p>

                  <p className="text-slate-400 text-sm mt-2">
                    {appointment.date}
                  </p>

                  <p className="text-slate-400 text-sm">
                    {appointment.time}
                  </p>

                  <span className="inline-block mt-4 text-green-400 bg-green-500/10 px-3 py-1 rounded-full text-xs">
                    Confirmed
                  </span>

                </div>

                <button
                  type="button"
                  onClick={onAppointment}
                  className="text-blue-400 mt-4"
                >
                  View appointment →
                </button>

              </div>
            ) : (
              <div className="mt-5">

                <p className="text-slate-500">
                  No upcoming appointment.
                </p>

                <button
                  type="button"
                  onClick={onFindHospital}
                  className="text-blue-400 mt-4"
                >
                  Find a hospital →
                </button>

              </div>
            )}

          </section>

          {/* QUEUE */}

          <section className="bg-slate-900 border border-slate-800 rounded-2xl p-6">

            <h2 className="text-xl font-bold">
              Live Queue
            </h2>

            {queueData ? (
              <div className="mt-5">

                <div className="bg-slate-950 rounded-xl p-5">

                  <p className="text-slate-500 text-sm">
                    Token
                  </p>

                  <p className="text-4xl font-bold text-blue-400 mt-1">
                    {queueData.token}
                  </p>

                  <p className="text-slate-400 text-sm mt-3">
                    {queueData.hospitalName}
                  </p>

                  <p className="text-slate-400 text-sm mt-1">
                    {queueData.peopleAhead} ahead
                  </p>

                </div>

                <button
                  type="button"
                  onClick={onQueue}
                  className="text-blue-400 mt-4"
                >
                  Track queue →
                </button>

              </div>
            ) : (
              <div className="mt-5">

                <p className="text-slate-500">
                  You are not currently in a queue.
                </p>

                <button
                  type="button"
                  onClick={onFindHospital}
                  className="text-blue-400 mt-4"
                >
                  Find a hospital →
                </button>

              </div>
            )}

          </section>

        </div>

      </main>
    </div>
  );
}

/* =========================================================
   NOTIFICATIONS
   ========================================================= */

function NotificationsPage({
  notifications,
  onBack,
  onMarkAllRead,
  onClear,
  onMarkRead,
}) {
  const unreadCount = notifications.filter((item) => item.unread !== false).length;

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      <Navbar />
      <main className="max-w-4xl mx-auto px-6 py-10">
        <button type="button" onClick={onBack} className="flex items-center gap-2 text-slate-400 hover:text-white mb-8">
          <ArrowLeft size={18} /> Back to Dashboard
        </button>
        <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4">
          <div>
            <h1 className="text-4xl font-bold">Notifications</h1>
            <p className="text-slate-400 mt-2">{unreadCount} unread · Appointment and queue updates.</p>
          </div>
          <div className="flex gap-3">
            <button type="button" onClick={onMarkAllRead} disabled={!unreadCount} className="px-4 py-2 rounded-xl bg-blue-600 disabled:opacity-40">Mark all read</button>
            <button type="button" onClick={onClear} disabled={!notifications.length} className="px-4 py-2 rounded-xl bg-slate-800 disabled:opacity-40">Clear all</button>
          </div>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-2xl mt-8 divide-y divide-slate-800">
          {notifications.length === 0 ? (
            <div className="p-8 text-slate-500">No notifications yet.</div>
          ) : notifications.map((notification) => (
            <div key={notification.id} className={`p-5 flex gap-4 ${notification.unread !== false ? "bg-blue-500/5" : ""}`}>
              <div className="bg-blue-500/10 text-blue-400 p-3 rounded-xl h-fit"><Activity size={19} /></div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <p className="font-semibold">{notification.title}</p>
                  {notification.unread !== false && <span className="w-2 h-2 rounded-full bg-blue-400" aria-label="Unread" />}
                </div>
                <p className="text-slate-400 text-sm mt-1">{notification.message}</p>
                <p className="text-slate-600 text-xs mt-2">{notification.time}</p>
              </div>
              {notification.unread !== false && (
                <button type="button" onClick={() => onMarkRead(notification.id)} className="text-blue-400 text-sm hover:text-blue-300 self-center">Mark read</button>
              )}
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}

/* =========================================================
   NAVBAR
   ========================================================= */

function Navbar({
  onDashboard,
}) {
  return (
    <nav className="border-b border-slate-800">

      <div className="max-w-7xl mx-auto px-6 py-5 flex justify-between items-center">

        <button
          type="button"
          onClick={onDashboard}
          className="flex items-center gap-3"
        >

          <div className="bg-blue-600 p-2 rounded-xl">
            <Hospital size={25} />
          </div>

          <span className="text-xl font-bold">
            Smart Hospital Network
          </span>

        </button>

        <div className="flex items-center gap-3">

          <div className="bg-slate-900 border border-slate-800 px-4 py-2 rounded-xl flex items-center gap-2">

            <User size={17} />

            <span className="text-sm">
              Patient
            </span>

          </div>

        </div>

      </div>

    </nav>
  );
}

/* =========================================================
   SMALL COMPONENTS
   ========================================================= */

function InfoBox({
  icon,
  title,
  value,
}) {
  return (
    <div className="bg-slate-950 border border-slate-800 rounded-xl p-5">

      <div className="text-blue-400 mb-3">
        {icon}
      </div>

      <p className="text-sm text-slate-500">
        {title}
      </p>

      <p className="text-xl font-bold mt-1">
        {value}
      </p>

    </div>
  );
}

function ReviewScore({
  label,
  value,
}) {
  return (
    <div className="bg-slate-900 rounded-lg p-3 text-center">

      <div className="text-yellow-400 font-bold">
        {value}
      </div>

      <div className="text-xs text-slate-500 mt-1">
        {label}
      </div>

    </div>
  );
}

function Reason({
  title,
  value,
}) {
  return (
    <div className="bg-slate-950 border border-slate-800 rounded-xl p-5">

      <p className="text-slate-500 text-sm">
        {title}
      </p>

      <p className="text-xl font-bold mt-2">
        {value}
      </p>

    </div>
  );
}

function DetailRow({
  label,
  value,
}) {
  return (
    <div className="flex justify-between gap-4">

      <span className="text-slate-500">
        {label}
      </span>

      <span className="font-medium text-right">
        {value}
      </span>

    </div>
  );
}

export default App;